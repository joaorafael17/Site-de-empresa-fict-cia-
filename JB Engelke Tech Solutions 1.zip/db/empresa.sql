CREATE DATABASE IF NOT EXISTS empresa;
USE empresa;

DROP TABLE IF EXISTS produtos;
DROP TABLE IF EXISTS novidades;

CREATE TABLE produtos (
  id_prod INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(75),
  valor FLOAT,
  qtdestoque INT
);

INSERT INTO produtos (nome, valor, qtdestoque) VALUES
('Servidor Inteligente', 12500.00, 10),
('Software de Gestao Empresarial', 2999.00, 50),
('Firewall Corporativo', 7800.00, 20),
('Servico de Cloud Privado', 1200.00, 100);

CREATE TABLE novidades (
  id_nov INT PRIMARY KEY AUTO_INCREMENT,
  resumo VARCHAR(40),
  descricao VARCHAR(200)
);

INSERT INTO novidades (resumo, descricao) VALUES
('Nova Unidade em São Paulo', 'Expandimos nossos serviços para São Paulo - Capital!'),
('Lançamento do JubraAI', 'Desenvolvemos IA para automação de processos empresariais.'),
('Nova Plataforma  JB Trade Solutions', 'Apresentamos solução completa de e-commerce B2B.'),
('Certificação ISO 27001', 'Garantimos máxima proteção de dados com ISO 27001.'),
('Reconhecimento GPTW 2025', 'TechWave foi eleita uma das melhores empresas para trabalhar pela Great Place to Work.');
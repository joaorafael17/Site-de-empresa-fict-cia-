<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "empresa";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Conexao falhou: " . $conn->connect_error);
}
?>
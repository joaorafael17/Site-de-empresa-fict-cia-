<?php
include 'conexao.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Produtos - JB Engelke Tech Solutions</title>
    <link rel="icon" type="image/png" href="assets/image.png">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav>
        <a href="../index.html">🏠 Home</a>
        <a href="../sobre.html">ℹ️ Sobre</a>
        <a href="produtos.php">🛒 Produtos</a>
        <a href="novidades.php">📰 Novidades</a>
        <a href="../contato.html">📞 Contato</a>
    </nav>
    <main>
        <h1>Produtos</h1>
        <?php
        $sql = "SELECT * FROM produtos";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($prod = $result->fetch_assoc()) {
                echo '<section>';
                echo '<h2>' . htmlspecialchars($prod["nome"]) . '</h2>';
                echo '<p>Valor: R$ ' . number_format($prod["valor"], 2, ',', '.') . '</p>';
                echo '<p>Estoque: ' . htmlspecialchars($prod["qtdestoque"]) . ' unidades</p>';
                echo '</section>';
            }
        } else {
            echo '<p>Não há produtos cadastrados no momento.</p>';
        }
        ?>
    </main>
</body>
</html>